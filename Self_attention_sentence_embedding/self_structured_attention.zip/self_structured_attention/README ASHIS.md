Ashis note:
========================================= 
https://github.com/kaushalshetty/Structured-Self-Attention
another site: https://github.com/ExplorerFreda/Structured-Self-Attentive-Sentence-Embedding
=========================================

Run classification.py file. 
There are two types of classification, binary or multi. Select your option.

- Data is loading from imdb site. 
  Data format is [ [top frequent word index of review], label(0 or 1) ]

- Model parameters are in _config.json, model_params.json file

- Used pytorch to run the model (check attention folder)
- Used python to create html file for Visualization (check Visualization folder)
- You can also use embedding of words as input (check glove folder)

- My code is in MIMIC_process folder to process note data and keeping data in input format
- use dataprocess.data_loader_my to run code for MIMIC data


======================
Data Processing note:

There are 42K admissions with note.
I kept 8K for test data. This data is not same as log_reg data.


After 5 epochs, training acc: .92
On test data, Accuracy: 0.88325

===========================
(36539, 2)
(8042, 2)

Model: Logistic regression (using max in ICU duration)
AUC: 0.8696
Accuracy:0.8472

Model: Logistic regression (using max in total admission)
AUC: 0.9149
Accuracy:0.8569

Model: Logistic regression (using max,min in total admission)
AUC: 0.9207
Accuracy:0.8615
===========================









Author's note:
=========================================
# Structured Self-attentive sentence embeddings 
Implementation for the paper A Structured Self-Attentive Sentence Embedding, which was published in ICLR 2017: https://arxiv.org/abs/1703.03130 .
#### USAGE:
For binary sentiment classification on imdb dataset run :
`python classification.py "binary"`

For multiclass classification on reuters dataset run :
`python classification.py "multiclass"`

You can change the model parameters in the `model_params.json file`
Other tranining parameters like number of attention hops etc can be configured in the `config.json` file.

If you want to use pretrained glove embeddings , set the `use_embeddings` parameter to `"True"` ,default is set to False. Do not forget to download the `glove.6B.50d.txt` and place it in the glove folder.



#### Implemented:
* Classification using self attention
* Regularization using Frobenius norm
* Gradient clipping
* Visualizing the attention weights

Instead of pruning ,used averaging over the sentence embeddings.

#### Visualization:
After training, the model is tested on 100 test points. Attention weights for the 100 test data are retrieved and used to visualize over the text using heatmaps. A file visualization.html gets saved in the visualization/ folder after successful training. The visualization code was provided by Zhouhan Lin (@hantek). Many thanks.


Below is a shot of the visualization on few datapoints.
![alt text](https://github.com/kaushalshetty/Structured-Self-Attention/blob/master/visualization/attention.png "Attention Visualization")



Training accuracy 93.4%
Tested on 1000 points with 90.2% accuracy

---

