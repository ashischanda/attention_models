# Making input data of discharge notes 
# input data is word_index

import pickle
from collections import defaultdict
import csv
import string
from stop_words import get_stop_words 
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
stop_words = get_stop_words('english')

admission_details_dict = pickle.load( open("/home/ashis/ASHIS/3.2_Kidney_problem/LABEVENTS/FILES/admission_details_dict_checked_chief_complaint_diagnosis.p", "rb"))

admidic=defaultdict(list)
with open('/home/ashis/ASHIS/1.2_MyDesk/MIMIC/data/csv_data/NOTEEVENTS.csv', 'r') as csvfile:
     spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')
     for row in spamreader:
         admID = row[ 2 ]
         if row[6]=='Discharge summary' and admID in admission_details_dict:
             # removing newline, punctation, making lower case
             admidic[ row[2] ].append( row[-1].replace('\n',' ').translate(str.maketrans('','',string.punctuation)).lower() )
             

## ****************************************************************************
# counting frequency one times in one note. If "pt" is three times in a single note, we take it 1
u=defaultdict(int)
for note_index in admidic:
    single_note_w = set()
    
    for note in admidic[ note_index ]:
        line= note.strip('\n').split()
        for j in line:
            single_note_w.add(j)
            
    for w in single_note_w:
        u[w]=u[w]+1    #counting frequency in note
## ****************************************************************************

def hasdigit(word):
    for ch in word:
        if ch.isdigit():
            return True
    return False
    

frequency_threshold = 200
notesvocab =defaultdict(int)
for i in u:
        if i.isdigit()==False:               # non digit word (i.e. 22, 40) 
            if hasdigit(i) ==False:         # no digit_word (i.e. 79yo, 150ml)
                
                if u[i]> frequency_threshold:                     # checking frequency 
                    if i not in stop_words:
                        notesvocab[i]=u[i]
    # frequency threshold 100 creates 14404 words 


print ("\nTotal vocabulary: " + str( len(notesvocab)) )
print ("\nTotal visits with discharge notes:  " + str( len( admidic )) )

#word_to_id  : {dict} words mapped to indices
word_to_id = {}
word_to_id["<PAD>"] = 0
word_to_id["<START>"] = 1
word_to_id["<UNK>"] = 2
count = 3
for w in notesvocab:
    word_to_id[ w ] = count
    count +=1
    
ind2word = {}    
for word, ind in word_to_id.items():
    ind2word[ind] = word    
# ******************************************************** word / voca part is done


# *****************************************************************************
admCodes = pickle.load( open("/home/ashis/ASHIS/3.2_Kidney_problem/prof_q4/admission_dict_diag", "rb") )
kidney_codes = ["584", "584.5", "584.6", "584.7", "584.8", "584.9" ]
def  getActualLabel(admID):    
    if admID in admCodes:
        code_st = admCodes[ admID ]
        code_st = code_st.split("$")        
        for ICD9_code in code_st:
            if ICD9_code in kidney_codes: 
                return 1                
        return 0        
    else:
        return 0
# *****************************************************************************
# *****************************************************************************

notedata = []   # each adm has [ word_index, label ]
note_length = []
for admID, values in admidic.items():  
    label = getActualLabel( admID )
    word_index = []
    
    #one admdic might have multiple discharge_notes
    for line in values:    
       thisline=line.strip('\n').split() 
         
       for word in thisline:
           if notesvocab[ word ]!=0:           # checking if the word is in frequent dictionary list or not
              word_index.append( word_to_id[ word ] )
              
    # if note length is less than 200, don't add          
    if len( word_index) < 200:
        continue
    
    note_length.append( len(word_index ) )          
    notedata.append( [word_index, label] )       

          
#shuffle the dataset            
arr_x = np.array( notedata )
np.random.shuffle( arr_x )

np.save('data_x',arr_x)
print (arr_x.shape)
#pickle.dump( arr_x ,  open("data_x.p", "wb" ) )
pickle.dump( word_to_id, open("word_to_id.p", "wb")) 
pickle.dump( ind2word, open("ind2word.p", "wb"))   