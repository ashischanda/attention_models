#https://pythonawesome.com/train-and-visualize-hierarchical-attention-networks/

import util.yelp as yelp
from hnatt import HNATT

YELP_DATA_PATH = '/home/ashis/Downloads/HAN/yelp.csv'
SAVED_MODEL_DIR = 'saved_models'
SAVED_MODEL_FILENAME = 'model.h5'
EMBEDDINGS_PATH = '/home/ashis/Downloads/HAN2/glove.6B/glove.6B.100d.txt'

def getY(pred):
    y_hat = []
    for i in range ( len(pred) ):
        t = [0] * len( pred[i] )
        index = -1
        m = -1
        for j in range( len( pred[i] ) ):
            if pred[i][j] > m:
                m= pred[i][j]
                index = j
        t[index] = 1
        y_hat.append( t )
        
    return y_hat
    
def acc(y, yhat):
    j=0
    c =0
    for row in y:
       for k in range( len(row) ):
           if row[k]==1:
               break
           
       if yhat[j][ k ] ==1:
           c+=1
       j+=1
      
    return c/j
    
if __name__ == '__main__':
	(train_x, train_y), (test_x, test_y) = yelp.load_data(path=YELP_DATA_PATH, size=1e4, binary=False)

	# initialize HNATT 
	h = HNATT()	
	h.train(train_x, train_y, 
		batch_size=8,
		epochs= 15,
		embeddings_path=EMBEDDINGS_PATH, 
		saved_model_dir=SAVED_MODEL_DIR,
		saved_model_filename=SAVED_MODEL_FILENAME)

	h.load_weights(SAVED_MODEL_DIR, SAVED_MODEL_FILENAME)

	# embeddings = h.word_embeddings(train_x)
	preds = h.predict(test_x)
	# print(preds)
	# import pdb; pdb.set_trace()

	# print attention activation maps across sentences and words per sentence
	activation_maps = h.activation_maps(
		'they have some pretty interesting things here. i will definitely go back again.')
	print(activation_maps)
	#'''
     # 0.521  acc
     # actual label:
	'''
          a = test_y.sum(axis=0)
          a
          Out[28]: array([156., 181., 271., 728., 664.])
          728/2000
          Out[29]: 0.364
     '''
     