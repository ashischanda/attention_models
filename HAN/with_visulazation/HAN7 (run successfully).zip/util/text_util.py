import string
import spacy
from spacy.lang.en import English
from spacy.tokenizer import Tokenizer

STOP_WORDS = ['the', 'a', 'an']
nlp = English()

#nlp = spacy.load('en_core_web_sm', disable = ['ner', 'parser', 'tagger'])

nlp.add_pipe(nlp.create_pipe('sentencizer'))

from gensim.parsing.preprocessing import remove_stopwords
from nltk import tokenize
from nltk.tokenize import RegexpTokenizer
tokenizer = RegexpTokenizer(r'\w+')   #retain only alphanumeric


def normalize(text):
	text = text.lower().strip()
	#'''
     # There was a problem in their code (in sentence making). So, I wrote this par
     # Gensim stopword are very powerful. It removes "my, me, for, and, a, the, an, to, go
	text =  remove_stopwords( text )   
	sentences = tokenize.sent_tokenize(text)       # Making sentences in list format
 
	cleaned_lines =[]
	# making lower case, remove digit, remove special char, new lines
	for line in sentences:
         tokens = [t.lower() for t in tokenizer.tokenize( line ) if not t.isnumeric()]
         if len(tokens) <1:   # no empty sentences
             continue
         text =  ' '.join(tokens)
         cleaned_lines.append( text )
         
	if len(cleaned_lines) <1:
         return ["nothing"]

	return cleaned_lines
	'''
 
	doc = nlp(text)
	filtered_sentences = []
	for sentence in doc.sents:
		filtered_tokens = list()
		for i, w in enumerate(sentence):
			s = w.string.strip()
			if len(s) == 0 or s in string.punctuation and i < len(doc) - 1:
				continue
			if s not in STOP_WORDS:
				s = s.replace(',', '.')
				filtered_tokens.append(s)
		filtered_sentences.append(' '.join(filtered_tokens))
	return filtered_sentences
     '''